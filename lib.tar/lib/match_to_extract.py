#!/opt/opsware/agent/bin/python

## Written by: John Rigler
## 10/21/2015

import csv
import socket

new_list = []

with open('newest_td_extract.csv', 'rb') as f:
    reader = csv.reader(f)
    your_list = list(reader)

records = len(your_list)
hostname=socket.gethostname()

for x in range(0,records):
    ci = your_list[x][0]
    host = your_list[x][1]
    domain = your_list[x][2]
    environment = your_list[x][3]
    lob = your_list[x][4]
    ip = your_list[x][5]
    instance = your_list[x][6]
    release = your_list[x][7]
    osver = your_list[x][8]
    sn = your_list[x][9]
    status = your_list[x][10]
    os = your_list[x][11]
    pv = your_list[x][12]
    owner = your_list[x][13]
    n = your_list[x][14]
    o = your_list[x][15]
    p = your_list[x][16]

    if hostname == host:
        print
        print   "ci =>\t\t", ci
        print   "host =>\t\t", host 
        print   "domain =>\t", domain 
        print   "environment =>\t", environment
        print   "lob =>\t\t", lob 
        print   "instance =>\t", instance
        print   "release =>\t", release
        print   "osver =>\t", osver
        print   "sn =>\t\t", sn
        print   "status =>\t", status
        print   "os =>\t\t", os 
        print   "pv =>\t\t", pv 
        print   "owner =>\t", owner 
        print   "n =>\t\t", n
        print   "o =>\t\t", o
        print   "p =>\t\t", p
        print
    

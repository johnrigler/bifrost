#!/usr/bin/python

import json
from pprint import pprint

with open('/tmp/data.json') as data_file:    
	    data = json.load(data_file)

	    pprint(data)
	    #data["mention_name"][0]["id"]
	    #print ("Name: " + data["items"][0]["id"])
	    #print (data["items"])
	    id = data["items"][0]["id"]
	    print "ID: "
	    print id
	    print ("Mention Name: " + data["items"][0]["mention_name"])
	    print ("Name: " + data["items"][0]["name"])
	    #data["version"]
